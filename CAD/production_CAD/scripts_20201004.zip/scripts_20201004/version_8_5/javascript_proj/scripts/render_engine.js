// TODO: 
// -render engine object for render engine variables

var id; // parameter for setInterval()/clearInterval()
var scaleFactor; // between 0.5 and 1, smaller than 0.5 cuts off text
var ii;
var lines;
var maxLines;
var winH; // mm
var winW; // mm
var painDotDia;
// keep track of paint dots
var paintDotCount = 0;
var dotXCoord = new Array(256);
var dotYCoord = new Array(256)

var mapName = "";
var logData = "";


function startRenderEngine(){

	scaleFactor = 0.5;
	ii = 0;
	maxLines = 0;
	winH = 1000; // mm
	winW = 1000; // mm
	paintDotDia = 20;
	paintDotCount = 0;
	mapName = "";
	logData = "";
	
	mapName = document.getElementById("mapNameSpace").value;
	logData = document.getElementById("logSpace").value;
	lines = logData.split("\n", 7600); // 150 sec x 50 data points/sec = 7500 lines
	maxLines = lines.length;
	
	// original size 1300 x 1000
	// 50% scale 800 x 500 (text pane does not decrease, always 300 wide)
	// 75% scale 1050 x 750 (text pane does not decrease, always 300 wide)
	
	// TODO: How to do createCanvas(width, height) here?
	
	id = setInterval(drawFunction, 20); // start looping drawFunction at 20 ms intervals
	
	// run and example buttons disabled, stop button enabled
	document.getElementById("buttonRun").disabled = true;
	document.getElementById("buttonExample").disabled = true;
	document.getElementById("buttonStop").disabled = false;

	
}


function stopRenderEngine() {

	clearInterval(id); // stop looping
	
	// run and example buttons enabled, stop button disabled
	document.getElementById("buttonRun").disabled = false;
	document.getElementById("buttonExample").disabled = false;
	document.getElementById("buttonStop").disabled = true;

}


// TODO: check if functionis 
function drawFunction() {
	
	var myVars = lines[ii].split(",");
	// only draw when parsed data is not blank
	if (lines[ii].length >= 12) {
		graphicsRectangleFilled(0, 0, scaleFactor*(winW)+300, scaleFactor*winH, 128, 128, 128); // background
		drawMap(0, 0, winW, winH, scaleFactor, mapName); // replace with image load
		drawPaintDots(myVars, scaleFactor);
		drawBot(parseFloat(myVars[2]), parseFloat(myVars[3]), parseFloat(myVars[4]), parseInt(myVars[8]), scaleFactor); // x(mm), y(mm), theta(rad), led, scale
		drawGridOverlay(0, 1000, 0, 1000, 100, 100, scaleFactor); // xMin(mm), xMax(mm), yMin(mm), yMax(mm), xStep(mm), yStep(mm), scale
		
		// the rest is the data panel
		// velocity indicator [5] leftMotor, [6] right motor
		drawVerticalSlider (50, 1065, parseFloat(myVars[5]), -100, 100, scaleFactor);// TL x(mm), TL y(mm), value, min val, max val, scale
		drawVerticalSlider (200, 1065, parseFloat(myVars[6]), -100, 100, scaleFactor);
		// [7] sensor indicator
		drawVerticalSlider(120, 720, parseFloat(myVars[7]), 0, 250, scaleFactor);
		// labels for the indicators
		drawLabel(30, 980, "Left Velocity", scaleFactor);
		drawLabel(170, 980, "Right Velocity", scaleFactor);
		drawLabel(100, 735, "Line Sensor", scaleFactor);
	}
	
	ii++;
	// don't overflow	
	if(ii >= maxLines) {
		ii = maxLines - 1;	
		stopRenderEngine(); // stop looping
	}

}




/// @brief Draw the robot.
///
/// Reference frames:
/// - World frame has +ive  x-axis to the right, +ive y-axis forward. Origin at
/// bottom left of map.
/// - Robot body frame has +ive x-axis to the right, +ive y-axis forward.
/// Origin at the center of the robot.
///
/// @param x X coordinate of the center of the robot [mm]
/// @param y Y coordinate of the center of the robot [mm]
/// @param theta Rotation, y-axis from north, or x-axis from east, CCW +ive [rad]
/// @param ledOn Indicates whether onboard LED is on or off, 1 is on, 0 is off
/// @param scale Value to scale the robot, typically 0.5 to 1.0 [dimensionless]
///
/// @return Void
//
function drawBot(x, y, theta, ledOn, scale) {
  
	var botW = 100, botL = 100, wheelW = 15, wheelL = 50, casterDia = 20, ledDia = 20, sensorW = 20, sensorL = 10;
	var x0, x1, x2, x3, y0, y1, y2, y3; // chassis
	var x4, x5, x6, x7, y4, y5, y6, y7; // right wheel
	var x8, x9, x10, x11, y8, y9, y10, y11; // left wheel
	var x12, y12; // rear wheel caster
	var x13, y13; // LED
	var x14, y14, x15, y15, x16, y16, x17, y17; // line sensor

	// chassis (CCW from top left corner)
	x0 = x + rotX(-botW/2, botL/2, theta);
	y0 = y + rotY(-botW/2, botL/2, theta);
	x1 = x + rotX(-botW/2, -botL/2, theta);
	y1 = y + rotY(-botW/2, -botL/2, theta);
	x2 = x + rotX(botW/2, -botL/2, theta);
	y2 = y + rotY(botW/2, -botL/2, theta);
	x3 = x + rotX(botW/2, botL/2, theta);
	y3 = y + rotY(botW/2, botL/2, theta);

	// right wheel (CCW from top left corner)
	x4 = x + rotX(botW/2, wheelL/2, theta);
	y4 = y + rotY(botW/2, wheelL/2, theta);
	x5 = x + rotX(botW/2, -wheelL/2, theta);
	y5 = y + rotY(botW/2, -wheelL/2, theta);
	x6 = x + rotX(botW/2 + wheelW/2, -wheelL/2, theta);
	y6 = y + rotY(botW/2 + wheelW/2, -wheelL/2, theta);
	x7 = x + rotX(botW/2 + wheelW/2, wheelL/2, theta);
	y7 = y + rotY(botW/2 + wheelW/2, wheelL/2, theta);

	// left wheel (CCW from top left corner)
	x8 = x + rotX(-botW/2 - wheelW/2, wheelL/2, theta);
	y8 = y + rotY(-botW/2 - wheelW/2, wheelL/2, theta);
	x9 = x + rotX(-botW/2 - wheelW/2, -wheelL/2, theta);
	y9 = y + rotY(-botW/2 - wheelW/2, -wheelL/2, theta);
	x10 = x + rotX(-botW/2, -wheelL/2, theta);
	y10 = y + rotY(-botW/2, -wheelL/2, theta);
	x11 = x + rotX(-botW/2, wheelL/2, theta);
	y11 = y + rotY(-botW/2, wheelL/2, theta);

	// rear wheel caster
	x12 = x + rotX(0, -botL/2, theta);
	y12 = y + rotY(0, -botL/2, theta);

	// LED
	x13 = x + rotX(0, botL/4, theta);
	y13 = y + rotY(0, botL/4, theta);

	// line sensor (CCW from top left corner)
	x14 = x + rotX(-sensorW/2, botL/2 + sensorL/2, theta);
	y14 = y + rotY(-sensorW/2, botL/2 + sensorL/2, theta);
	x15 = x + rotX(-sensorW/2, botL/2 - sensorL/2, theta);
	y15 = y + rotY(-sensorW/2, botL/2 - sensorL/2, theta);
	x16 = x + rotX(sensorW/2, botL/2 - sensorL/2, theta);
	y16 = y + rotY(sensorW/2, botL/2 - sensorL/2, theta);
	x17 = x + rotX(sensorW/2, botL/2 + sensorL/2, theta);
	y17 = y + rotY(sensorW/2, botL/2 + sensorL/2, theta);

	// dont forget to convert to image frame, and then scale it
	graphicsQuadFilled(scale*x0, scale*(winH - y0), scale*x1, scale*(winH - y1), scale*x2, scale*(winH - y2), scale*x3, scale*(winH - y3), 155, 155, 155); // chassis
	graphicsQuad(scale*x0, scale*(winH - y0), scale*x1, scale*(winH - y1), scale*x2, scale*(winH - y2), scale*x3, scale*(winH - y3), 0, 0, 0); // chassis outline
	graphicsQuadFilled(scale*x4, scale*(winH - y4), scale*x5, scale*(winH - y5), scale*x6, scale*(winH - y6), scale*x7, scale*(winH - y7), 0, 0, 0); // right wheel
	graphicsQuadFilled(scale*x8, scale*(winH - y8), scale*x9, scale*(winH - y9), scale*x10, scale*(winH - y10), scale*x11, scale*(winH - y11), 0, 0, 0); // right wheel
	graphicsEllipseFilled(scale*x12, scale*(winH - y12), scale*casterDia, scale*casterDia, 0, 0, 0); // caster
  
	if(ledOn == 1) {
		graphicsEllipseFilled(scale*x13, scale*(winH - y13), scale*ledDia, scale*ledDia, 220, 220, 25); // LED on
	} else {
		graphicsEllipseFilled(scale*x13, scale*(winH - y13), scale*ledDia, scale*ledDia, 90, 90, 50); // LED off   
	}
	graphicsEllipse(scale*x13, scale*(winH - y13), scale*ledDia, scale*ledDia, 0, 0, 0); // LED outline

	graphicsQuadFilled(scale*x14, scale*(winH - y14), scale*x15, scale*(winH - y15), scale*x16, scale*(winH - y16), scale*x17, scale*(winH - y17), 220, 50, 50); // line sensor outline
	graphicsQuad(scale*x14, scale*(winH - y14), scale*x15, scale*(winH - y15), scale*x16, scale*(winH - y16), scale*x17, scale*(winH - y17), 0, 0, 0); // line sensor outline

}


/// @brief Given x and y coordinates, rotate by theta and return the new x coordinate.
///
function rotX(x, y, theta) {
  
	return x*Math.cos(theta) - y*Math.sin(theta);
  
}


/// @brief Given x and y coordinates, rotate by theta and return the new y coordinate.
///
function rotY(x, y, theta) {
  
	return x*Math.sin(theta) + y*Math.cos(theta);
  
}


/// @brief Draw paint dots when each new paint dot is logged once.
///
/// Keeps a track of all the paint dots so far
///
function drawPaintDots(dataLine, scale){
  
  // idx 9, 10, 11 = isPaintingNow, xCoord, yCoord
  
  var isPaintingNow = parseInt(dataLine[9]);
  var j = 0;
  //if(isPaintingNow == 1) { println(paintDotCount); }
  //println(isPaintingNow);
  if ( (isPaintingNow == 1) && (paintDotCount < 255) ) {
    
    // add point to list of coordinates
    dotXCoord[paintDotCount] = parseInt(dataLine[10]);
    dotYCoord[paintDotCount] = parseInt(dataLine[11]);
    paintDotCount = paintDotCount + 1;
    //println(paintDotCount);
    
    
  }
  
  // now draw all existing paint dots
  for (j=0; j<paintDotCount; j++){
    graphicsEllipseFilled(scale*dotXCoord[j], scale*(winH - dotYCoord[j]), scale*paintDotDia, scale*paintDotDia, 0, 204, 0);  // paint dot
	graphicsEllipse(scale*dotXCoord[j], scale*(winH - dotYCoord[j]), scale*paintDotDia, scale*paintDotDia, 0, 0, 0);  // paint dot outline
	
  }
  
}


/// @brief Draw a vertical scale with markers and indicated quantity.
///
/// Draws a scale 200 pixels long, with scale markers at 10% intervals. It is
/// not scaled up or down but its position is scaled.
///
/// TODO:
/// -fix scaling bug where vertical position is messed up if min is negative
///
/// @param xMM TL x coordinate in the margin area frame
/// @param yMM TL y coordinate in the margin area frame
/// @param val value of quantity to indicate [quantity units]
/// @param min Minimum value of quantity to indicate [quantity units]
/// @param max Maximum value of quantity to indicate [quantity units]
/// @param scale Value to scale everything, typically 0.5 to 1.0 [dimensionless]
///
/// @return Void
///
function drawVerticalSlider(xMM, yMM, val, min, max, scale) {
  
  var verticalScaleLen = 200, xMarginOffset = scale*1000; // mm
  var dYScaled = val/(max - min)*verticalScaleLen; // mm
  var tickLen = 10; // mm
  var digitXOffset = 15, digitYOffset = 6; // mm
  var indicLen = 10; // mm
  
  // indicator
  graphicsTriangleFilled(xMM + xMarginOffset, winH - (yMM - verticalScaleLen + dYScaled), xMM + xMarginOffset - indicLen, winH - (yMM - verticalScaleLen + dYScaled + indicLen), xMM + xMarginOffset - indicLen, winH - (yMM - verticalScaleLen + dYScaled - indicLen), 0, 0, 0);
  //graphicsEllipseFilled(xMM + xMarginOffset, winH - (yMM - verticalScaleLen + dYScaled), 10, 10, 0, 0, 0);
  //graphicsEllipseFilled(1100, 100, 10, 10, 0, 0, 0);
  var i = min;
  
  // ticks
  for ( i=min; i<=max; i=i+(max-min)/10.0) {
    // min and max are value units, not mm or pixel, so convert i just like dyScaled above
    graphicsLine(xMM + xMarginOffset, winH - (yMM - verticalScaleLen + i/(max-min)*verticalScaleLen), xMM + xMarginOffset + tickLen, winH - (yMM - verticalScaleLen + i/(max-min)*verticalScaleLen), 0, 0, 0);
    graphicsPrintInt(i, xMM + xMarginOffset + digitXOffset, winH - (yMM - verticalScaleLen + i/(max-min)*verticalScaleLen - digitYOffset), 15, 0, 0, 0);
  }
  
}


function drawLabel(xMM, yMM, thisText, scale) {
  
  var xMarginOffset = scale*1000;
  graphicsPrintString(thisText, xMM + xMarginOffset, winH - yMM, 15, 0, 0, 0);
  
}


// all units/axes in mm
function drawGridOverlay(xMin, xMax, yMin, yMax, xStep, yStep, scale) {
  
	var i = 0, j = 0;
	var lineR = 128, lineG = 128, lineB = 128;

	// parameters are in mm, make sure to  convert to pixels and pixel frame
	// also scale the pixels
	// vertical lines
	for(i=xMin; i<=xMax; i=i+xStep) {
		graphicsLine(scale*i, scale*(winH - yMin), scale*i, scale*(winH - yMax), lineR, lineG, lineB);
	}
	// horizontal lines
	for(j=yMin; j<=yMax; j=j+yStep) {    
		graphicsLine(scale*xMin, scale*(winH - j), scale*xMax, scale*(winH - j), lineR, lineG, lineB); 
	}
}


// placeholder, need to replace with actual image function that loads from file
function drawMap(x, y, imW, imH, scale, mapName) {

	graphicsRectangleFilled(x, y, scale*imW, scale*imH, 255, 255, 255);
	graphicsRectangle(x, y, scale*imW, scale*imH, 0, 0, 0); // outline
	if (mapName == "map1") {
		drawMap1v85(scale);	
	} else if (mapName == "map2") {
		drawMap2v85(scale);
	} else if (mapName == "map3") {
		drawMap3v85(scale);	
	} else if (mapName == "map4") {
		drawMap4v85(scale);	
	}
	

}

// From Processing code, void map1map2v6_1(
function drawMap1v85(scale) {
  var lineWidthThin = 12;
  // map 1 and 2 for v6_1, thinner lines
  drawBox3(100, 100, 0, lineWidthThin, scale); // start
  //drawBox2(400, 100, 0, lineWidthThin); // next door
  //drawBox2(100, 900, 180, lineWidthThin); // opposite
  //drawBox2(900, 900, 180, lineWidthThin); // opposite corner
  //drawBox2(500, 900, 180, lineWidthThin); // opposite middle
  //drawBox2(700, 200, 315, lineWidthThin); // center-ish
  
}


// From Processing code, void map1map2v6_1()
function drawMap2v85(scale) {
  var lineWidthThin = 12;
  // map 1 and 2 for v6_1, thinner lines
  drawBox3(100, 100, 0, lineWidthThin, scale); // start
  drawBox3(400, 100, 0, lineWidthThin, scale); // next door
  drawBox3(100, 900, 180, lineWidthThin, scale); // opposite
  drawBox3(900, 900, 180, lineWidthThin, scale); // opposite corner
  drawBox3(500, 900, 180, lineWidthThin, scale); // opposite middle
  drawBox3(700, 200, 315, lineWidthThin, scale); // center-ish
  
}


// From Processing code, void map3v6_1()
function drawMap3v85(scale) {
  
  var thisLineWidth = 12;
  var whiteSpace = 4; // mm
    
  //outer
  graphicsLineWide(scale*(thisLineWidth/2 + whiteSpace), scale*(winH - 200 + thisLineWidth/2), scale*(thisLineWidth/2 + whiteSpace), scale*(winH - 1000 + whiteSpace), scale*thisLineWidth, 0, 0, 0);
  graphicsLineWide(scale*(whiteSpace), scale*(winH - 1000 + thisLineWidth/2 + whiteSpace), scale*(1000 - whiteSpace), scale*(winH - 1000 + thisLineWidth/2 + whiteSpace), scale*thisLineWidth, 0, 0, 0);
  graphicsLineWide(scale*(1000 - thisLineWidth/2 - whiteSpace), scale*(winH - 1000 + whiteSpace), scale*(1000 - thisLineWidth/2 - whiteSpace), scale*(winH - 200), scale*thisLineWidth, 0, 0, 0);
  graphicsLineWide(scale*(1000 - whiteSpace), scale*(winH - 200), scale*(200 - thisLineWidth/2), scale*(winH - 200), scale*thisLineWidth, 0, 0, 0);
  graphicsLineWide(scale*200, scale*(winH - 200), scale*200, scale*(winH - 800 + thisLineWidth/2), scale*thisLineWidth, 0, 0, 0);
  graphicsLineWide(scale*(200 - thisLineWidth/2), scale*(winH - 800), scale*(800 + thisLineWidth/2), scale*(winH - 800), scale*thisLineWidth, 0, 0, 0);
  
  // inner
  graphicsLineWide(scale*800, scale*(winH - 600 - thisLineWidth/2), scale*800, scale*(winH - 400), scale*thisLineWidth, 0, 0, 0);
  graphicsLineWide(scale*800, scale*(winH - 600), scale*(400 - thisLineWidth/2), scale*(winH - 600), scale*thisLineWidth, 0, 0, 0);
  graphicsLineWide(scale*400, scale*(winH - 600), scale*400, scale*(winH - 400), scale*thisLineWidth, 0, 0, 0);
  graphicsLineWide(scale*(400 - thisLineWidth/2), scale*(winH - 400), scale*500, scale*(winH - 400), scale*thisLineWidth, 0, 0, 0); // gate
  graphicsLineWide(scale*700, scale*(winH - 400), scale*(800 + thisLineWidth/2), scale*(winH - 400), scale*thisLineWidth, 0, 0, 0); // gate
  
  // blockade
  graphicsLineWide(scale*800, scale*(winH - 400), scale*800, scale*(winH - 200), scale*thisLineWidth, 0, 0, 0);
  
}

// From Processing code, void map4v6_1()
function drawMap4v85(scale) {
  
  var thisLineWidth = 33;
  
  // first level
  graphicsLineWide(scale*100, scale*(winH - 100), scale*400, scale*(winH - 150), scale*thisLineWidth, 0, 0, 0);
  graphicsLineWide(scale*400, scale*(winH - 150), scale*700, scale*(winH - 100), scale*thisLineWidth, 0, 0, 0);
  graphicsArcWide(scale*700, scale*(winH - 200 - 100), scale*200, scale*thisLineWidth, 90, 0, 1, 0, 0, 0); 
  graphicsLineWide(scale*900, scale*(winH - 300), scale*900, scale*(winH - 400), scale*thisLineWidth, 0, 0, 0);
  // first level line end fillers
  graphicsCircleFilled(scale*400, scale*(winH - 150), scale*thisLineWidth/2, 0, 0, 0);
  graphicsCircleFilled(scale*700, scale*(winH - 100), scale*thisLineWidth/2, 0, 0, 0);
  
  // second level
  graphicsArcWide(scale*800, scale*(winH - 400), scale*100, scale*thisLineWidth, 360, 180, 1, 0, 0, 0);
  graphicsArcWide(scale*600, scale*(winH - 400), scale*100, scale*thisLineWidth, 180, 360, 1, 0, 0, 0);
  graphicsArcWide(scale*400, scale*(winH - 400), scale*100, scale*thisLineWidth, 360, 180, 1, 0, 0, 0);
  graphicsArcWide(scale*200, scale*(winH - 400), scale*100, scale*thisLineWidth, 180, 360, 1, 0, 0, 0);
  graphicsLineWide(scale*100, scale*(winH - 400), scale*100, scale*(winH - 600), scale*thisLineWidth, 0, 0, 0);

  // third level
  // right angle
  graphicsLineWide(scale*(100-thisLineWidth/2), scale*(winH - 600), scale*(300+thisLineWidth/2), scale*(winH - 600), scale*thisLineWidth, 0, 0, 0);
  graphicsLineWide(scale*300, scale*(winH - 600), scale*300, scale*(winH - 700), scale*thisLineWidth, 0, 0, 0);
  graphicsCircleFilled(scale*300, scale*(winH - 700), scale*thisLineWidth/2, 0, 0, 0); // line end filler
  // zig zag
  thisLineWidth = 33/3.0*2.0;
  graphicsLineWide(scale*300, scale*(winH - 700), scale*400, scale*(winH - 900), scale*thisLineWidth, 0, 0, 0);
  graphicsLineWide(scale*400, scale*(winH - 900), scale*600, scale*(winH - 700), scale*thisLineWidth, 0, 0, 0);  
  graphicsCircleFilled(scale*400, scale*(winH - 900), scale*thisLineWidth/2, 0, 0, 0); // line end filler
  thisLineWidth = 33/3.0;
  graphicsLineWide(scale*592, scale*(winH - 692), scale*800, scale*(winH - 900), scale*thisLineWidth, 0, 0, 0);
  graphicsLineWide(scale*800, scale*(winH - 900), scale*(1000 - 4 - 16), scale*(winH - 700 - 4 - 16), scale*thisLineWidth, 0, 0, 0);
  graphicsCircleFilled(scale*800, scale*(winH - 900), scale*thisLineWidth/2, 0, 0, 0); // line end filler
  
  
}


// TODO: Fix the box corners
function drawBox2(x, y, thetaDeg, lineWidth, scale) {
    
  var boxW = 200, boxH = 200, theta = thetaDeg/180.0*3.14159;  
  var x0, x1, x2, x3, y0, y1, y2, y3; // chassis
  var whiteSpace = 4; // mm

  // (CCW from top left corner)
  x0 = x + rotX(-boxW/2 + lineWidth/2 + whiteSpace, boxH/2, theta);
  y0 = y + rotY(-boxW/2 + lineWidth/2 + whiteSpace, boxH/2, theta);
  x1 = x + rotX(-boxW/2 + lineWidth/2 + whiteSpace, -boxH/2 + lineWidth/2 + whiteSpace, theta);
  y1 = y + rotY(-boxW/2 + lineWidth/2 + whiteSpace, -boxH/2 + lineWidth/2 + whiteSpace, theta);
  x2 = x + rotX(boxW/2 - lineWidth/2 - whiteSpace, -boxH/2 + lineWidth/2 + whiteSpace, theta);
  y2 = y + rotY(boxW/2 - lineWidth/2 - whiteSpace, -boxH/2 + lineWidth/2 + whiteSpace, theta);
  x3 = x + rotX(boxW/2 - lineWidth/2 - whiteSpace, boxH/2, theta);
  y3 = y + rotY(boxW/2 - lineWidth/2 - whiteSpace, boxH/2, theta);
  
  // don't forget to convert from physical units to pixel units (flipped y)
  graphicsLineWide(scale*x0, scale*(winH - y0), scale*x1, scale*(winH - y1), scale*lineWidth, 0, 0, 0);
  graphicsLineWide(scale*x1, scale*(winH - y1), scale*x2, scale*(winH - y2), scale*lineWidth, 0, 0, 0);
  graphicsLineWide(scale*x2, scale*(winH - y2), scale*x3, scale*(winH - y3), scale*lineWidth, 0, 0, 0);
  
  
}


/// @brief Draw a three-sided box.
///
/// @param x X-coordinate of center of box [mm]
/// @param y Y-coordinate of center box [mm]
/// @param thetaDeg Angular rotation of the box [deg]
/// @param lineWidth Line width of the box outline [mm]
/// @param scale The scale to draw the box at (typically 0.5 to 1.0)
///
/// Proper box corner overlaps suitable to HTML Canvas drawing. There are six
/// points:
///
///  0         5
///   |       |
///   |       | 
/// 1 |_______| 4
///   2       3
///
/// @return Void
///
function drawBox3(x, y, thetaDeg, lineWidth, scale) {
    
  var boxW = 200, boxH = 200, theta = thetaDeg/180.0*3.14159;  
  var x0, x1, x2, x3, x4, x5, y0, y1, y2, y3, y4, y5; // line coordinates, CCW from top left [mm]
  var whiteSpace = 4; // mm

  // (CCW from top left corner)
  x0 = x + rotX(-boxW/2 + lineWidth/2 + whiteSpace, boxH/2, theta);
  y0 = y + rotY(-boxW/2 + lineWidth/2 + whiteSpace, boxH/2, theta);
  x1 = x + rotX(-boxW/2 + lineWidth/2 + whiteSpace, -boxH/2 + lineWidth/2 + whiteSpace, theta);
  y1 = y + rotY(-boxW/2 + lineWidth/2 + whiteSpace, -boxH/2 + lineWidth/2 + whiteSpace, theta);
  //                                                  added + lineWidth/2 
  x2 = x + rotX(-boxW/2 + whiteSpace, -boxH/2 + lineWidth/2 + whiteSpace, theta);
  y2 = y + rotY(-boxW/2 + whiteSpace, -boxH/2 + lineWidth/2 + whiteSpace, theta);
  //            removed + lineWidth/2      
  x3 = x + rotX(boxW/2 - whiteSpace, -boxH/2 + lineWidth/2 + whiteSpace, theta);
  y3 = y + rotY(boxW/2 - whiteSpace, -boxH/2 + lineWidth/2 + whiteSpace, theta);
  //           removed - lineWidth/2
  x4 = x + rotX(boxW/2 - lineWidth/2 - whiteSpace, -boxH/2 + lineWidth/2 + whiteSpace, theta);
  y4 = y + rotY(boxW/2 - lineWidth/2 - whiteSpace, -boxH/2 + lineWidth/2 + whiteSpace, theta);
  //                                                 added + lineWidth/2
  x5 = x + rotX(boxW/2 - lineWidth/2 - whiteSpace, boxH/2, theta);
  y5 = y + rotY(boxW/2 - lineWidth/2 - whiteSpace, boxH/2, theta);
  
  // don't forget to convert from physical units to pixel units (flipped y)
  graphicsLineWide(scale*x0, scale*(winH - y0), scale*x1, scale*(winH - y1), scale*lineWidth, 0, 0, 0);
  graphicsLineWide(scale*x2, scale*(winH - y2), scale*x3, scale*(winH - y3), scale*lineWidth, 0, 0, 0);
  graphicsLineWide(scale*x4, scale*(winH - y4), scale*x5, scale*(winH - y5), scale*lineWidth, 0, 0, 0);
  
  
}