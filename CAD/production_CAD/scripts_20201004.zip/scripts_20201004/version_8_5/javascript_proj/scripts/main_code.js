function mainFunction() {
	
	// disable run and example buttons
	
	// Do some housekeeping behind the scenes
	clearLogBuffers();
	
	// make sure map files have been loaded
	if ((typeof map1Data === 'undefined') || (typeof map2Data === 'undefined') || (typeof map3Data === 'undefined') || (typeof map4Data === 'undefined') ) {
		alert("Error: map data not loaded.");
	} else {	
		// Now run the user code
		var myCodeString;
		myCodeString = document.getElementById("codeSpace").value; // get existing code from code space
		var myCodeResult = eval(myCodeString);
		
		startRenderEngine();	// initialize render engine, load sim data, start the animation
								// it will stop once it goes through all the sim data
	}
	
	//selectMap("map2");
	//robotStartPosition(100, 100, 0);
	//robotConnect();
	//
	//paint();
	//right();
	//forward();
	//
	//robotDisconnect();

}


function loadExampleCode() {

	// prepare example code string
	var x = "";
	x = "selectMap(\"map1\");\n";
	x = x + "robotStartPosition(100, 100, 0);\n";
	x = x + "robotConnect();\n\n";
	x = x + "blink();\n";
	x = x + "forward();\n";
	x = x + "right();\n";
	x = x + "forward();\n";
	x = x + "\nrobotDisconnect();\n";
	
	// load it into the code space
	document.getElementById("codeSpace").value = x;

}


function clearLogBuffers() {

	// clear the fptr log buffer
	fptr = "";
	document.getElementById("logSpace").value = fptr;
	// clear the map name log buffer
	mapfptr = "";

}