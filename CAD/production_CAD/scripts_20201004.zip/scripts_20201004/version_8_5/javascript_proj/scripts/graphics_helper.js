// Based on drawing library V08, 23 Sep 2020

var c = document.getElementById("myCanvas");
var ctx = c.getContext("2d");

/// @brief Draw a pixel.
///
/// @param x x-coordinate (pixels)
/// @param y y-coordinate (pixels)
/// @param red red value, 0-255
/// @param green green value, 0-255
/// @param blue blue value, 0-255
/// 
/// @return Void
///
function graphicsPixel(x, y, red, green, blue){
	ctx.beginPath();
	ctx.moveTo(x, y);
	ctx.lineTo(x+1, y+1);
	ctx.lineWidth = 1;
	ctx.strokeStyle = "rgb(" + red + "," + green + "," + blue + ")";
	ctx.stroke();
	ctx.closePath();
}


/// @brief Draw a line.
///
/// @param x1 start point x-coordinate (pixels)
/// @param y1 start point y-coordinate (pixels)
/// @param x2 end point x-coordinate (pixels)
/// @param y2 end point y-coordinate (pixels)
/// @param red red value, 0-255
/// @param green green value, 0-255
/// @param blue blue value, 0-255
/// 
/// @return Void
///
function graphicsLine(x1, y1, x2, y2, red, green, blue){

	ctx.beginPath();
	ctx.moveTo(x1, y1);
	ctx.lineTo(x2, y2);
	ctx.lineWidth = 1;
	ctx.strokeStyle = "rgb(" + red + "," + green + "," + blue + ")";
	ctx.stroke();
	ctx.closePath();
}


/// @brief Draw a line.
///
/// @param x1 start point x-coordinate (pixels)
/// @param y1 start point y-coordinate (pixels)
/// @param x2 end point x-coordinate (pixels)
/// @param y2 end point y-coordinate (pixels)
/// @param width line width (pixels)
/// @param red red value, 0-255
/// @param green green value, 0-255
/// @param blue blue value, 0-255
/// 
/// @return Void
///
function graphicsLineWide(x1, y1, x2, y2, lineWidth, red, green, blue){

	ctx.beginPath();
	ctx.moveTo(x1, y1);
	ctx.lineTo(x2, y2);
	ctx.lineWidth = lineWidth;
	ctx.strokeStyle = "rgb(" + red + "," + green + "," + blue + ")";
	ctx.stroke();
	//ctx.closePath();
}


/// @brief Draw an empty rectangle.
///
/// @param x top left corner x-coordinate (pixels)
/// @param y top left corner y-coordinate (pixels)
/// @param width width of rectangle (pixels)
/// @param height height of rectangle (pixels)
/// @param red red value, 0-255
/// @param green green value, 0-255
/// @param blue blue value, 0-255
/// 
/// @return Void
///
function graphicsRectangle(x, y, width, height, red, green, blue){

	ctx.beginPath();
	ctx.rect(x, y, width, height);
	ctx.lineWidth = 1;
	ctx.strokeStyle = "rgb(" + red + "," + green + "," + blue + ")";
	ctx.stroke();
	ctx.closePath();
	
}


/// @brief Draw a filled rectangle.
///
/// @param x top left corner x-coordinate (pixels)
/// @param y top left corner y-coordinate (pixels)
/// @param width width of rectangle (pixels)
/// @param height height of rectangle (pixels)
/// @param red red value, 0-255
/// @param green green value, 0-255
/// @param blue blue value, 0-255
/// 
/// @return Void
///
function graphicsRectangleFilled(x, y, width, height, red, green, blue){

	ctx.beginPath();
	ctx.rect(x, y, width, height);
	ctx.fillStyle = "rgb(" + red + "," + green + "," + blue + ")";
	ctx.fill();
	ctx.closePath();
	
}


/// @brief Draw an empty circle.
///
/// @param x center x-coordinate (pixels)
/// @param y center y-coordinate (pixels)
/// @param radius radius of circle (pixels)
/// @param red red value, 0-255
/// @param green green value, 0-255
/// @param blue blue value, 0-255
/// 
/// @return Void
///
function graphicsCircle(x, y, radius, red, green, blue) {

	ctx.beginPath();	
	ctx.arc(x, y, radius, 0, 2*Math.PI); 
	ctx.lineWidth = 1;
	ctx.strokeStyle = "rgb(" + red + "," + green + "," + blue + ")";
	ctx.stroke();
	ctx.closePath();

}


/// @brief Draw a filled circle.
///
/// @param x center x-coordinate (pixels)
/// @param y center y-coordinate (pixels)
/// @param radius radius of circle (pixels)
/// @param red red value, 0-255
/// @param green green value, 0-255
/// @param blue blue value, 0-255
/// 
/// @return Void
///
function graphicsCircleFilled(x, y, radius, red, green, blue) {

	ctx.beginPath();
	ctx.arc(x, y, radius, 0, 2*Math.PI); 
	ctx.fillStyle = "rgb(" + red + "," + green + "," + blue + ")";
	ctx.fill();
	ctx.closePath();

}


/// @brief Draw an arc.
///
/// @param x center x-coordinate (pixels)
/// @param y center y-coordinate (pixels)
/// @param radius radius of arc (pixels)
/// @param startAngle starting angle (deg)
/// @param endAngle ending angle (deg)
/// @param direction 1 for counter clockwise, -1 for clockwise
/// @param red red value, 0-255
/// @param green green value, 0-255
/// @param blue blue value, 0-255
/// 
/// @return Void
///
function graphicsArc(x, y, radius, startAngle, endAngle, direction, red, green, blue) {

	ctx.beginPath();
	if (direction == 1) {
		ctx.arc(x, y, radius, startAngle/180.0*Math.PI, endAngle/180.0*Math.PI, true); // counterClockwise = true
	} else if (direction == -1) {
		tx.arc(x, y, radius, startAngle/180.0*Math.PI, endAngle/180.0*Math.PI, false); // counterClockwise = false
	}
	ctx.lineWidth = 1;
	ctx.strokeStyle = "rgb(" + red + "," + green + "," + blue + ")";
	ctx.stroke();
	//ctx.closePath();

}

/// @brief Draw an arc.
///
/// @param x center x-coordinate (pixels)
/// @param y center y-coordinate (pixels)
/// @param radius radius of arc (pixels)
/// @param startAngle starting angle (deg)
/// @param endAngle ending angle (deg)
/// @param direction 1 for counter clockwise, -1 for clockwise
/// @param red red value, 0-255
/// @param green green value, 0-255
/// @param blue blue value, 0-255
/// 
/// @return Void
///
function graphicsArcWide(x, y, radius, lineWidth, startAngle, endAngle, direction, red, green, blue) {

	ctx.beginPath();
	if (direction == 1) {
		ctx.arc(x, y, radius, startAngle/180.0*Math.PI, endAngle/180.0*Math.PI, true); // counterClockwise = true
	} else if (direction == -1) {
		tx.arc(x, y, radius, startAngle/180.0*Math.PI, endAngle/180.0*Math.PI, false); // counterClockwise = false
	}
	ctx.lineWidth = lineWidth;
	ctx.strokeStyle = "rgb(" + red + "," + green + "," + blue + ")";
	ctx.stroke();
	//ctx.closePath();

}


/// @brief Draw an empty ellipse.
///
/// @param x center x-coordinate (pixels)
/// @param y center y-coordinate (pixels)
/// @param width width of ellipse (pixels)
/// @param height height of ellipse (pixels)
/// @param red red value, 0-255
/// @param green green value, 0-255
/// @param blue blue value, 0-255
/// 
/// @return Void
///
function graphicsEllipse(x, y, width, height, red, green, blue) {
		
	ctx.beginPath();
	ctx.moveTo(x-width/2, y);
	ctx.bezierCurveTo(x-width/2, y-height/2, x+width/2, y-height/2, x+width/2, y);
	ctx.bezierCurveTo(x+width/2, y+height/2, x-width/2, y+height/2, x-width/2, y);
	ctx.lineWidth = 1;
	ctx.strokeStyle = "rgb(" + red + "," + green + "," + blue + ")";
	ctx.stroke();
	ctx.closePath();
	
}


/// @brief Draw a filled ellipse.
///
/// @param x center x-coordinate (pixels)
/// @param y center y-coordinate (pixels)
/// @param width width of ellipse (pixels)
/// @param height height of ellipse (pixels)
/// @param red red value, 0-255
/// @param green green value, 0-255
/// @param blue blue value, 0-255
/// 
/// @return Void
///
function graphicsEllipseFilled(x, y, width, height, red, green, blue) {
		
	ctx.beginPath();
	ctx.moveTo(x-width/2, y);
	ctx.bezierCurveTo(x-width/2, y-height/2, x+width/2, y-height/2, x+width/2, y);
	ctx.bezierCurveTo(x+width/2, y+height/2, x-width/2, y+height/2, x-width/2, y);
	ctx.fillStyle = "rgb(" + red + "," + green + "," + blue + ")";
	ctx.fill();
	ctx.closePath();
	
}


/// @brief Draw an empty triangle.
///
/// @param x1 first point x-coordinate (pixels)
/// @param y1 first point y-coordinate (pixels)
/// @param x2 second point x-coordinate (pixels)
/// @param y2 second point y-coordinate (pixels) 
/// @param x3 third point x-coordinate (pixels)
/// @param y3 third point y-coordinate (pixels)
/// @param red red value, 0-255
/// @param green green value, 0-255
/// @param blue blue value, 0-255
/// 
/// @return Void
///
function graphicsTriangle(x1, y1, x2, y2, x3, y3, red, green, blue) {

	ctx.beginPath();
	ctx.moveTo(x1, y1);
	ctx.lineTo(x2, y2);
	ctx.lineTo(x3, y3);
	ctx.lineTo(x1, y1);
	ctx.lineWidth = 1;
	ctx.strokeStyle = "rgb(" + red + "," + green + "," + blue + ")";
	ctx.stroke();
	ctx.closePath();

}


/// @brief Draw a filled triangle.
///
/// @param x1 first point x-coordinate (pixels)
/// @param y1 first point y-coordinate (pixels)
/// @param x2 second point x-coordinate (pixels)
/// @param y2 second point y-coordinate (pixels) 
/// @param x3 third point x-coordinate (pixels)
/// @param y3 third point y-coordinate (pixels)
/// @param red red value, 0-255
/// @param green green value, 0-255
/// @param blue blue value, 0-255
/// 
/// @return Void
///
function graphicsTriangleFilled(x1, y1, x2, y2, x3, y3, red, green, blue) {

	ctx.beginPath();
	ctx.moveTo(x1, y1);
	ctx.lineTo(x2, y2);
	ctx.lineTo(x3, y3);
	ctx.lineTo(x1, y1);
	ctx.fillStyle = "rgb(" + red + "," + green + "," + blue + ")";
	ctx.fill();
	ctx.closePath();

}


/// @brief Draw an empty four-sided polygon.
///
/// @param x1 first point x-coordinate (pixels)
/// @param y1 first point y-coordinate (pixels)
/// @param x2 second point x-coordinate (pixels)
/// @param y2 second point y-coordinate (pixels) 
/// @param x3 third point x-coordinate (pixels)
/// @param y3 third point y-coordinate (pixels)
/// @param x4 third point x-coordinate (pixels)
/// @param y4 third point y-coordinate (pixels)
/// @param red red value, 0-255
/// @param green green value, 0-255
/// @param blue blue value, 0-255
/// 
/// @return Void
///
function graphicsQuad(x1, y1, x2, y2, x3, y3, x4, y4, red, green, blue) {
	ctx.beginPath();
	ctx.moveTo(x1, y1);
	ctx.lineTo(x2, y2);
	ctx.lineTo(x3, y3);
	ctx.lineTo(x4, y4);
	ctx.lineWidth = 1;
	ctx.closePath();
	ctx.strokeStyle = "rgb(" + red + "," + green + "," + blue + ")";
	ctx.stroke();
}


/// @brief Draw a filled four-sided polygon.
///
/// @param x1 first point x-coordinate (pixels)
/// @param y1 first point y-coordinate (pixels)
/// @param x2 second point x-coordinate (pixels)
/// @param y2 second point y-coordinate (pixels) 
/// @param x3 third point x-coordinate (pixels)
/// @param y3 third point y-coordinate (pixels)
/// @param x4 third point x-coordinate (pixels)
/// @param y4 third point y-coordinate (pixels)
/// @param red red value, 0-255
/// @param green green value, 0-255
/// @param blue blue value, 0-255
/// 
/// @return Void
///
function graphicsQuadFilled(x1, y1, x2, y2, x3, y3, x4, y4, red, green, blue) {
	ctx.beginPath();
	ctx.moveTo(x1, y1);
	ctx.lineTo(x2, y2);
	ctx.lineTo(x3, y3);
	ctx.lineTo(x4, y4);
	ctx.closePath();
	ctx.fillStyle = "rgb(" + red + "," + green + "," + blue + ")";
	ctx.fill();
}


/// @brief Draw text.
///
/// @param textString the text to draw
/// @param x bottom left, x-coordinate (pixels)
/// @param y bottom left, y-coordinate (pixels)
/// @param textSize of text (pixels)
/// @param red red value, 0-255
/// @param green green value, 0-255
/// @param blue blue value, 0-255
/// 
/// @return Void
///
function graphicsPrintString(textString, x, y, textSize, red, green, blue){

	ctx.beginPath();
	ctx.font = textSize + "px Arial";
	ctx.fillStyle = "rgb(" + red + "," + green + "," + blue + ")";
	ctx.fillText(textString, x, y);
	ctx.fill();
	ctx.closePath();
	
}


/// @brief Draw an integer number.
///
/// @param number the number to draw
/// @param x bottom left, x-coordinate (pixels)
/// @param y bottom left, y-coordinate (pixels)
/// @param textSize of text (pixels)
/// @param red red value, 0-255
/// @param green green value, 0-255
/// @param blue blue value, 0-255
/// 
/// @return Void
///
function graphicsPrintInt(number, x, y, textSize, red, green, blue){

	ctx.beginPath();
	ctx.font = textSize + "px Arial";
	ctx.fillStyle = "rgb(" + red + "," + green + "," + blue + ")";
	ctx.fillText(number.toString(), x, y);
	ctx.fill();
	ctx.closePath();
	
}
