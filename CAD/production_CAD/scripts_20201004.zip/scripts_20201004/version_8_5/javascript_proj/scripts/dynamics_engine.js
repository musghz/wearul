var SIM_VERSION_MAJOR = 8;
var SIM_VERSION_MINOR = 5;
var MY_PI = 3.14159;
// duration of one time step of the simulation
var DT_SIM = 0.020;
var CHASSIS_WIDTH_MM = 100;
var CHASSIS_LENGTH_MM = 100;
var WORLD_WIDTH_MM = 1000;
var WORLD_LENGTH_MM = 1000;
// max. no. of paint dots
var NUM_DOTS_MAX = 255;
// paint dot diameter (unused?)
var DOT_DIA_MM = 20;
var MAX_NAME_STR_SIZE = 128;
// tie to spend executing each simulator instruction
var LINEAR_TRAVEL_TIME_SEC = 1.0;
var ANGULAR_TRAVEL_TIME_SEC = 1.0;
// time to wait after each simple instruction (right, left, etc.)
var INSTRUCTION_GAP_TIME_SEC = 0.5;

/// Robot object
///
/// Units and values below:
/// int line; // line number
/// double simTime; // [s]
/// double x; // xpos [mm]
/// double y; // ypos [mm]
/// double theta; // rotation, y-axis from north, or x-axis from east [rad]
/// double xVel; // x vel [mm/s]
/// double yVel; // y vel [mm/s]
/// double thetaVel; // angular rate [rad]
/// double leftMotVel; // -100 to 100
/// double rightMotVel; // -100 to 100
/// int lineSensor; // 0 to 1024
/// int bumpSensor; // 0 to 1024
/// int rangeSensor; // 0 to 1024
/// int led; // 0 or 1
/// double chassisWidth; // [mm]
/// double chassisLength; // [mm]
/// double worldWidth; // [mm]
/// double worldLength; // [mm]
/// int isPaintingNow; // paint dot created at current time step? 0 or 1
/// int nDots; // no. of paint dots
/// int dotXCoord[NUM_DOTS_MAX];
/// int dotYCoord[NUM_DOTS_MAX];
var robot = {

    line: 0,
    simTime: 0.0,
    x: 0.0,
    y: 0.0,
    theta: 0.0,
    xVel: 0.0,
    yVel: 0.0,
    thetaVel: 0.0,
    leftMotVel: 0.0,
    rightMotVel: 0.0,
    lineSensor: 0,
    bumpSensor: 0,
    rangeSensor: 0,
    led: 0,
    chassisWidth: 0.0,
    chassisLength: 0.0,
    worldWidth: 0.0,
    worldLength: 0.0,
    isPaintingNow: 0,
    nDots: 0,
    dotXCoord: new Array(NUM_DOTS_MAX),
    dotYCoord: new Array(NUM_DOTS_MAX)

};

var fptr = ""; // save simulation log
var mapfptr = ""; // save the map name
var mapData = new Array(1000);
var sillyCounterDoodleDoo = 0;
for (sillyCounterDoodleDoo=0; sillyCounterDoodleDoo<1000; sillyCounterDoodleDoo++) {
	mapData[sillyCounterDoodleDoo] = new Array(1000);
}


/// @brief Read analog value from an analog input port.
///
/// Line sensor on port 0 and range sensor on port 1.
///
/// @param port Analog port number (0 or 1).
///
/// @return Analog value between 0 and 1023.
///
function analogRead(port) {
    if (port == 0) {
        return robot.lineSensor;
    } else if (port == 1) {
        return robot.rangeSensor;
    } else {
        return 0; // nothing valid
    }
}


/// @brief Read digital value from a digital input port.
///
/// Bump sensor on port 0.
///
/// @param port Digital port number
///
/// @return Digital value (0 or 1).
///
function digitalRead(port) {
    if (port == 0) {
        return robot.bumpSensor;
    } else {
        return 0; // nothing valid
    }
}


/// @brief Write digital value to a digital output port.
///
/// LED on port 0.
///
/// @param port Digital port number
/// @param val Digital value (0 or 1).
///
/// @return Void
///
function digitalWrite(port, val) {
    if (port == 0) {
        if ((val == 0) || (val == 1)) {
            robot.led = val;
        }
    }
}

/// @brief Turn onboard LED on or off.
///
/// @param val On/off value, 0 for on, 1 for off
///
/// @return Void
///
function led(val) {

    digitalWrite(0, val);

}


/// @brief Set motor velocity for motor connected to a PWM port.
///
/// Left motor on port 0, right motor on port 1. Set to 100 for full speed
/// forward. Set to -100 for full speed backward. Set to 0 to stop motor.
///
/// @param port Motor port number.
/// @param vel Motor velocity (-100 to 100).
///
/// @return Void
///
function motorVelocity(port, vel) {


    // limit vel to +-100
    if (vel > 100.0) {
        vel = 100;
    } else if (vel < -100.0) {
        vel = -100;
    }

    // ignore invalid ports
    if(port == 0) {
        robot.leftMotVel = vel;
    } else if (port == 1) {
        robot.rightMotVel = vel;
    }

}


/// @brief Set motor velocity for left motor.
///
/// Set to 100 for full speed forward. Set to -100 for full speed backward. Set
/// to 0 to stop motor.
///
/// @param vel Motor velocity (-100 to 100).
///
/// @return Void
///
function leftMotorVelocity(vel) {

    motorVelocity(0, vel);

}


/// @brief Set motor velocity for right motor.
///
/// Set to 100 for full speed forward. Set to -100 for full speed backward. Set
/// to 0 to stop motor.
///
/// @param vel Motor velocity (-100 to 100).
///
/// @return Void
///
function rightMotorVelocity(vel) {

    motorVelocity(1, vel);

}


/// @brief Go forward one step (100 mm).
///
/// @return Void
///
function forward() {

    motorVelocity(0, 100);
    motorVelocity(1, 100);
    waitSeconds(LINEAR_TRAVEL_TIME_SEC);
    motorVelocity(0, 0);
    motorVelocity(1, 0);
    waitSeconds(INSTRUCTION_GAP_TIME_SEC);

}


/// @brief Go backward one step (100 mm).
///
/// @return Void
///
function backward() {

    motorVelocity(0, -100);
    motorVelocity(1, -100);
    waitSeconds(LINEAR_TRAVEL_TIME_SEC);
    motorVelocity(0, 0);
    motorVelocity(1, 0);
    waitSeconds(INSTRUCTION_GAP_TIME_SEC);

}


/// @brief Go backward one step (100 mm).
///
/// @return Void
///
function backward() {

    motorVelocity(0, -100);
    motorVelocity(1, -100);
    waitSeconds(LINEAR_TRAVEL_TIME_SEC);
    motorVelocity(0, 0);
    motorVelocity(1, 0);
    waitSeconds(INSTRUCTION_GAP_TIME_SEC);

}


/// @brief Turn right (90 degrees).
///
/// @return Void
///
function right() {

    motorVelocity(0, 78.5);
    motorVelocity(1, -78.5);
    waitSeconds(LINEAR_TRAVEL_TIME_SEC);
    motorVelocity(0, 0);
    motorVelocity(1, 0);
    waitSeconds(INSTRUCTION_GAP_TIME_SEC);

}


/// @brief Turn left (90 degrees).
///
/// @return Void
///
function left() {

    motorVelocity(0, -78.5);
    motorVelocity(1, 78.5);
    waitSeconds(LINEAR_TRAVEL_TIME_SEC);
    motorVelocity(0, 0);
    motorVelocity(1, 0);
    waitSeconds(INSTRUCTION_GAP_TIME_SEC);

}


/// @brief Blink the onboard LED 3 times.
///
/// The blink pattern is 1 second on, 1 second off.
///
/// @return Void
///
function blink() {

    var i = 0;
    for(i=0; i<3; i++) {
        led(1);
        waitSeconds(1);
        led(0);
        waitSeconds(1);
    }

}

/// @brief Read analog value from the line sensor.
///
/// An analog sensor can have a value of 0-1023 but this line sensor returns
/// a value of 0-255. A value of zero indicates that no light is being
/// reflected, that is, the surface is black. A value of 255 indicates that
/// all the light is being reflected, that is, the surface is white.
///
/// @return Analog value from 0 to 1023.
///
function lineSensor() {

    return analogRead(0);

}


/// @brief Get the actual time elapsed since the program started.
///
/// Use this for keeping track of time when not using the simulator.
///
/// @return Time in seconds.
///
function timeSecondsReal() {

    // currently not implemented
	return 0.0;
	//return (double)(clock()/((double)CLOCKS_PER_SEC));

}


/// @brief Wait for an actual amount of seconds.
///
/// Use this for making the program wait outside the simulator. This will not
/// affect the robot, so don't use it if you are trying to make the robot wait.
/// Can use whole seconds, e.g. 1, 2, 3, or partial seconds, e.g. 1.1, 2.5,
/// 5.7, etc.
///
/// @param sec Number of seconds.
///
/// @return Void
///
function waitSecondsReal(sec) {

	// currently not implemented

    //double startTime = timeSecondsReal();

    // ignore negative times
    //if (sec >= 0.0) {
        //while ((timeSecondsReal() - startTime) < sec) {
            // do nothing
        //}
    //}

}


/// @brief Wait for a simulated amount of seconds.
///
/// If you are using the simulator, use this. Can use whole seconds, e.g. 1,
/// 2, 3, or partial seconds, e.g. 1.1, 2.5, 5.7, etc.
///
/// You must to use this after every set of commands in order to give the
/// robot time to respond to your commands. This function updates the robot
/// dynamics. If you do not use this at all in your code, then your robot will
/// not have time to carry out any commands and the robot will never move.
///
/// @param sec Number of seconds.
///
/// @return Void
///
function waitSeconds (sec) {

    var startTime = 0.0;
    var runningTime = 0.0;

    // run all the simulation time steps that fit in this time interval
    while((runningTime - startTime) < sec){

        // update dynamics
        updateDynamics();
        // update sim time
        runningTime = runningTime + DT_SIM;
    }


}


/// @brief Get time elapsed since the simulation started.
///
/// Use this for keeping track of time when using the simulator.
///
/// @return Time in seconds.
///
function timeSeconds() {

    return robot.simTime;
}


/// @brief Place the robot on the map.
///
/// This is the second of 3 functions that must be called in main() before
/// writing any code. Internally, this initializes the robot simulator data
/// structure.
///
/// The angle is measured between the x-axis of the robot frame and the x-axis
/// of the world frame. Counter clockwise rotation is positive. When the angle
/// is zero, the robot is pointed in the forward direction in the world frame.
///
/// Reference frames:
/// - World frame has +ive  x-axis to the right, +ive y-axis forward. Origin at
/// bottom left of map.
/// - Robot body frame has +ive x-axis to the right, +ive y-axis forward.
/// Origin at the center of the robot.
///
/// @param x X coordinate of the starting location of the robot (world frame) [mm]
/// @param y Y coordinate of the starting location of the robot (world frame) [mm]
/// @param theta Starting direction of the robot world frame +ive counterclockwise [deg]
///
/// @return Void
///
function robotStartPosition(x, y, theta){

    var i = 0;

    robot.line = 0;
    robot.simTime = 0.0;
    robot.x = x;
    robot.y = y;
    robot.theta = theta/180.0*MY_PI;
    robot.xVel = 0.0;
    robot.yVel = 0.0;
    robot.thetaVel = 0.0;
    robot.chassisWidth = CHASSIS_WIDTH_MM;
    robot.chassisLength = CHASSIS_LENGTH_MM;
    robot.worldWidth = WORLD_WIDTH_MM;
    robot.worldLength = WORLD_LENGTH_MM;
    robot.nDots = 0;

    // initially all dots are hidden off screen
    for(i=0; i<NUM_DOTS_MAX; i++) {
        robot.dotXCoord[i] = -1000;
        robot.dotYCoord[i] = -1000;
    }


}


/// @brief Connect to the robot (start logging).
///
/// This is the third of 3 functions that must be called in main() before
/// writing any code. Internally, this opens the datalogging file for the
/// simulator world state.
///
/// This file is then used by the renderer to render the simulated world in
/// real-time.
///
/// @return Void
///
function robotConnect(){

    //fptr = fopen("sim_data/log.txt", "w");

    //if(fptr == NULL)
    //{
    //    printf("Error! Could not open log!");
    //    exit(1);
    //}
	
    waitSeconds(3.0*DT_SIM); // put SOMETHING in the log in case there is no code

}


/// @brief Select the map to use with the robot (load sensor data).
///
/// Internally, load sensor data for selected map. Also, write down the
/// selected map name to file so the renderer knows which map image to render.
///
/// This is the first of 3 functions that must be called in main() before
/// writing any code.
///
/// @param myMapName Map name without file extension, e.g., "map1" or "map2"
/// etc.
///
/// @return Void
///
function selectMap(myMapName) {

    var i=0, j=0, someInt=0;
	var n=0;

    for (j=0; j<WORLD_LENGTH_MM; j++) {
        for (i=0; i<WORLD_WIDTH_MM; i++) {
            //fscanf(mapfptr,"%d", &someInt);
            
            //mapData[i][j] = someInt;
			if (myMapName == "map1") {
				mapData[i][j] = map1Data[n];	
			} else if (myMapName == "map2") {
				mapData[i][j] = map2Data[n];	
			} else if (myMapName == "map3") {
				mapData[i][j] = map3Data[n];	
			} else if (myMapName == "map4") {
				mapData[i][j] = map4Data[n];	
			} else {
				mapData[i][j] = 0;			
			}
			
			n++;

        }
    }

    // log the name of the selected map to inform the renderer
    logMapName(myMapName);
}


/// @brief Log the name of the selected map to inform the renderer.
///
/// @param myMapName Map name without file extension, e.g., "map1" or "map2"
/// etc.
///
/// @return Void
///
function logMapName(myMapName) {

	mapfptr = myMapName;

}


/// @brief Disconnect from the robot (stop logging).
///
///
/// TODO: This function should do the actual posting of the data to the text area
///
/// Internally, close the datalogging file for the simulator world state. This
/// function must always be called at the end of the code.
///
/// @return Void
///
function robotDisconnect() {

    // close the log and/or post the log data somewhere
	document.getElementById("logSpace").value = fptr; 
	document.getElementById("mapNameSpace").value = mapfptr;

}


/// @brief Log the current simulator world state.
///
/// @param worldState Current world state.
///
/// @return Void
///
function logState(w) {

    var i = 0;
    // 9 state values
	fptr = fptr +
		w.line + "," +
		w.simTime.toFixed(3) + "," + 
		w.x.toFixed(1) + "," + 
		w.y.toFixed(1) + "," +
		w.theta.toFixed(3) + "," +
		w.leftMotVel.toFixed(1) + "," +
		w.rightMotVel.toFixed(1) + "," +
		w.lineSensor + "," +
		w.led + ",";

    // if paint dot created at current time step, and if at least 1 paint dot exists
    if( (w.isPaintingNow == 1) && (w.nDots > 0) ){
        // log a 1 for that, an the coordinates of the drawn markers
		fptr = fptr + "1," + w.dotXCoord[w.nDots - 1] + "," + w.dotYCoord[w.nDots - 1] + "\n";
    } else {
        // log a zero (not painting) and 0,0 for the coordinates (any value is fine since they won't be used)
		fptr = fptr + "0,0,0\n";
    }

    // now some other function must set isPaintingNow to zero


}

/// @brief Run the dynamics and sensor models for one time step.
///
/// Also increment the time step and and log the current state to file.
///
/// @return Void
///
function updateDynamics() {

    // increment time and line count
    robot.line = robot.line + 1;
    robot.simTime = robot.simTime + DT_SIM;

    // use velocity to move
    var tempX = robot.x, tempY = robot.y, tempTheta = robot.theta;
    var updated = diffWheelDynamics( robot.leftMotVel, robot.rightMotVel, robot.chassisWidth, DT_SIM, tempX, tempY, tempTheta);
    robot.x = updated.x; robot.y = updated.y; robot.theta = updated.theta;

    // read back new sensor data
    // TODO: range sensor a,d bump sensor
    robot.lineSensor = lineSensorModel(robot.x, robot.y, robot.theta, 0.0, robot.chassisLength/2.0);

    // log
    logState(robot);
    robot.isPaintingNow = 0; // reset this status for next iteration

}


/// @brief Simulate the dynamics of a differential drive robot.
///
/// Model assumes that wheels are on either side of the center of the robot.
/// The distance between them is the wheel base.
///
/// The angle is measured between the x-axis of the robot frame and the x-axis
/// of the world frame. Counter clockwise rotation is positive. When the angle
/// is zero, the robot is pointed in the forward direction in the world frame.
///
/// Reference frames:
/// - World frame has +ive  x-axis to the right, +ive y-axis forward. Origin at
/// bottom left of map.
/// - Robot body frame has +ive x-axis to the right, +ive y-axis forward.
/// Origin at the center of the robot.
///
/// The "proper" models from the references did not quite work, so a simplified
/// model is used. It is good enough.
///
/// Reference model sources:
/// http://www.cs.columbia.edu/~allen/F17/NOTES/icckinematics.pdf
/// https://people.cs.umu.se/thomash/reports/KinematicsEquationsForDifferentialDriveAndArticulatedSteeringUMINF-11.19.pdf
///
/// TODO: try more complicated model.
///
/// @param lefVel Left wheel velocity, +ive drives forward [mm/s].
/// @param rightVel Right wheel velocity, +ive drives forward [mm/s].
/// @param wheelBase Span-wise distance between the two wheels [mm].
/// @param deltaT Duration of one time step of the simulation [s].
/// @param x X coordinate of the robot position (world frame) [mm].
/// @param y Y coordinate of the robot position (world frame) [mm].
/// @param theta Direction of the robot (world frame) +ive counterclockwise [rad].
///
/// @return Object with modified x, y, theta
///
function diffWheelDynamics (leftVel, rightVel, wheelBase, deltaT, x, y, theta) {

    /*
    // TODO: fix issues with these "proper" dynamics
    double newTheta = 0, newX = 0, newY = 0, bigR = 0, omega = 0, iccX = 0, iccY = 0;
    // theta is with x-axis
    bigR = wheelBase/2.0*(rightVel + leftVel)/(rightVel - leftVel);
    omega = (rightVel - leftVel)/wheelBase;
    newTheta = omega*deltaT + *theta; // [rad]

    iccX = *x - bigR*sin(*theta);
    iccY = *y + bigR*cos(*theta);

    newX = (*x - iccX)*cos(omega*deltaT) - (*y - iccY)*sin(omega*deltaT) + iccX;
    newY = (*x - iccX)*sin(omega*deltaT) + (*y - iccY)*cos(omega*deltaT) + iccY;

    // update
    *x = newX;
    *y = newY;
    *theta = newTheta;
    */
	// cannot do pass by reference in javascript so returning x,y,theta in an object
	var modified = {
		x: 0.0,
		y: 0.0,
		theta: 0.0
	};
    // local velocities and displacements
    // CCW +ive
    //double tempTheta = *theta;
    var vFwd = (leftVel + rightVel)/2.0; // [mm/s]
    var vRot = (rightVel - leftVel)/wheelBase; // [rad/s]
    var sFwd = vFwd*deltaT; // [mm]
    var sRot = vRot*deltaT; // [rad]

    // get disp in global frame, move a little
    var sXGlobal = rotateX(0, sFwd, theta); // [mm]
    var sYGlobal = rotateY(0, sFwd, theta); // [mm]
    modified.x = x + sXGlobal;
    modified.y = y + sYGlobal;

    // apply global rotation
    modified.theta = theta + sRot;


    //*y = *y + vFwd*deltaT;
    //*y = *y + 1;
    //*theta = *theta + 5.0/50.0/180.0*3.1417;
	
	return modified;

}


/// @brief Calculate the x-coordinate of a point (x,y) after rotation.
///
/// Rotation about the origin (0,0).
///
/// @brief x The original x-coordinate.
/// @brief y The original y-coordinate.
/// @brief theta Angle by which to rotate the original point [rad].
///
/// @return X-coordinate of the point after rotation.
///
function rotateX(x, y, theta) {

  return x*Math.cos(theta) - y*Math.sin(theta);

}


/// @brief Calculate the y-coordinate of a point (x,y) after rotation.
///
/// Rotation about the origin (0,0).
///
/// @brief x The original x-coordinate.
/// @brief y The original y-coordinate.
/// @brief theta Angle by which to rotate the original point [rad].
///
/// @return Y-coordinate of the point after rotation.
///
function rotateY(x, y, theta) {

  return x*Math.sin(theta) + y*Math.cos(theta);

}


/// @brief Compute the current line sensor value based on the robot location.
///
/// Sensor value 0-255, with 0 being black and 255 being white, straight up
/// based on red value from RGB image data. The sensor is mounted in the middle
/// of the front edge of the robot.
///
/// The angle is measured between the x-axis of the robot frame and the x-axis
/// of the world frame. Counter clockwise rotation is positive. When the angle
/// is zero, the robot is pointed in the forward direction in the world frame.
///
/// Reference frames:
/// - World frame has +ive  x-axis to the right, +ive y-axis forward. Origin at
/// bottom left of map.
/// - Robot body frame has +ive x-axis to the right, +ive y-axis forward.
/// Origin at the center of the robot.
///
/// @param robotXWorldFrame Robot center x-coordinate (world frame) [mm].
/// @param robotYWorldFrame Robot center y-coordinate (world frame) [mm].
/// @param robotThetaWorldFrame Robot rotation angle in world frame [rad].
/// @param sensorXBodyFrame Sensor x-coordinate (robot frame) [mm].
/// @param sensorYBodyFrame Sensor y-coordinate (robot frame) [mm].
///
/// @return Sensor value in the range 0-255.
///
function lineSensorModel(robotXWorldFrame, robotYWorldFrame, robotThetaWorldFrame, sensorXBodyFrame, sensorYBodyFrame) {

    var imgX = 0, imgY = 0; // int
    var sensorXWorldFrame=0.0, sensorYWorldFrame=0.0; // double

    // find out the coordinates of the sensor in the world frame, given coordinates in local frame
    sensorXWorldFrame = robotXWorldFrame + rotateX(sensorXBodyFrame, sensorYBodyFrame, robotThetaWorldFrame);
    sensorYWorldFrame = robotYWorldFrame + rotateY(sensorXBodyFrame, sensorYBodyFrame, robotThetaWorldFrame);

    // for debugging, use this if sensor at robot center
    //sensorXWorldFrame = robotXWorldFrame;
    //sensorYWorldFrame = robotYWorldFrame; /

    // converting to image coordinates because the map data are in image frame, i.e. origin at top left of image
	// trunc() converts float to int
    imgX = Math.trunc(sensorXWorldFrame);
    imgY = WORLD_LENGTH_MM - Math.trunc(sensorYWorldFrame);
    // if array index out of bounds pick top left corner of image
    if ( (imgX >= WORLD_WIDTH_MM) || (imgX < 0) || (imgY >= WORLD_LENGTH_MM) || (imgY < 0) ) {
        imgX = 0;
        imgY = 0;
    }
    return mapData[imgX][imgY]; // remember, map data are stored in image frame
}


/// @brief Make a paint dot at the current robot location.
///
/// The world state keeps track of how many dots have been made and what their
/// coordinates are.
///
/// @return number of "paint dots" that have been used up.
///
function paint() {

    var myX = Math.trunc(robot.x); // int
    var myY = Math.trunc(robot.y); // int

    // draw more dots only if the "paint tank" has not emptied of "paint dots"
    if (robot.nDots < NUM_DOTS_MAX) {
        // mark the point for the latest dot at the current robot location
        robot.dotXCoord[robot.nDots] = myX;
        robot.dotYCoord[robot.nDots] = myY;

        robot.nDots = robot.nDots + 1; // update dot count;
        robot.isPaintingNow = 1; // paint dot generated at current time step (0 means no)
    }

    return robot.nDots; // this is how many "paint dots" have been used up
}


/// @brief Print version number to terminal.
///
/// @return void
///
function version() {

    var major = SIM_VERSION_MAJOR;
    var minor = SIM_VERSION_MINOR;
	
	var printString = "\nversion: " + major + "." + minor + "\n";

    console.log(printString);

}
